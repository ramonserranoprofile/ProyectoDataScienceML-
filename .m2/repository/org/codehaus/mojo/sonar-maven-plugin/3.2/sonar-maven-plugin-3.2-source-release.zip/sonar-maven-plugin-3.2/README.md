# SonarQube Maven Plugin

The project has moved to https://github.com/SonarSource/sonar-maven. This is only the relocation pom.
